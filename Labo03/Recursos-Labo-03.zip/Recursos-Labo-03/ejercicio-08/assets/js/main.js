const fibonacciCalculate=(/*recibe*/)=> {
    // Code 
}

const requestQuantity = () => {
    // Code
}

const main = () => {

}

main();
