
const plus = (/*recibe*/) => {
    //Code
};
const subtract = (/*recibe*/) =>{
    //Code
} ;
const multiply = (/*recibe*/) =>{
    //Code
} ;
const split = (/*recibe*/) => {
    //Code
};
const requestNumber = (/*recibe*/) => {
    //Code
};

const selectOperation = () => {
    //Code
};

const main = () => {
    //Code
}

main();
