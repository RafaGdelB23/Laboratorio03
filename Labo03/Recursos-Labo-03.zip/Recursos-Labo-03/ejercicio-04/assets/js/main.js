const createCounter = () => {
    //Code
}

const showCounter = (/*recibe*/) => {
    //Code
}

const requestNumber=()=>{
    
}

const main = () => {
   
}

main();
