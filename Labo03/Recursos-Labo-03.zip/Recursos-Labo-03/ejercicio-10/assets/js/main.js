const filterApproved = (/*recibe*/) => {
    //code 
}

const showApproved = (/*recibe*/) => {
   //code 
}

const main = () => {
    let students = [
        { nombre: 'Ana', notas: [7, 6, 5, 8] },
        { nombre: 'Juan', notas: [4, 5, 6, 4] },
        { nombre: 'María', notas: [6, 5, 7, 6] },
        { nombre: 'Pedro', notas: [3, 4, 5, 6] }
    ];
    
}

main();
