const searchNumber = (/*recibe*/) => {
    //Code
}

const requestNumber = () => {
    //Code
}

const main = () => {
    
}

main();
