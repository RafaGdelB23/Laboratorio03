const filterAvailableProducts = (/*recibe*/) => {
    //code 
}

const showProducts = (/*recibe*/) => {
    //code
}

const main = () => {
    
}

main();
