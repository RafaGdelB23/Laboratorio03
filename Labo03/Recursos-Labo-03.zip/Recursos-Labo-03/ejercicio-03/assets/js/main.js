const calculateFactorial = (/*recibe*/) => {
    //Code
}

const requestNumber = () => {
    //Code
}

const main = () => {
    //Code
}

main();
