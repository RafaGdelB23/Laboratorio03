const isPalindrome = (/*recibe*/) => {
    //Code
}

const requestChain = () => {
   //Code 
}

const main = () => {

}

main();