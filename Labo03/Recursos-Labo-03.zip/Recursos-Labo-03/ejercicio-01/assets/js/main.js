const countVotes = (/*recibe*/) => {
    //Code
}

const showResults = (/*recibe*/) => {
    //Code
}

const main = () => {
    let votes = [
        { candidate: 'Alice' },
        { candidate: 'Bob' },
        { candidate: 'Alice' },
        { candidate: 'Alice' },
        { candidate: 'Bob' }
    ];
    //Code

}

main();
